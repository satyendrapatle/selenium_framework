package com.murali.learnings.automation.selautomationfw.tests;



/**
 * Unit test for simple App.
 */
public class AppTest 
{
    /**
     * Rigorous Test :-)
     */
   // @Test
    public void shouldAnswerWithTrue()
    {
        //assertTrue( true );
    }
}
