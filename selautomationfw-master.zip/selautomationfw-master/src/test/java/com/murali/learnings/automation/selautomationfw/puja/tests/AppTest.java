package com.murali.learnings.automation.selautomationfw.puja.tests;



/**
 * Unit test for simple App.
 */
public class AppTest 
{
    /**
     * Rigorous Test :-)
     */
   // @Test
    public void shouldAnswerWithTrue()
    {
        //assertTrue( true );
    }
}
